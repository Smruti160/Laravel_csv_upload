<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\SitesController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::any('/dashboard', [SitesController::class, 'dashboard']);
Route::any('/add_customer', [SitesController::class, 'add_customer']);
Route::any('/add_product', [SitesController::class, 'add_product']);
Route::any('/product_list', [SitesController::class, 'product_list']);
Route::any('/add_to_cart/{id}', [SitesController::class, 'add_to_cart']);
Route::any('/cart', [SitesController::class, 'cart']);
Route::any('/remove_cart/{id}', [SitesController::class, 'remove_cart']);
