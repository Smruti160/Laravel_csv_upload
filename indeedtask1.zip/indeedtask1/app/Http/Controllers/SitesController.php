<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Customer;
use App\Models\Product;
use App\Models\Cart;
use DB;

class SitesController extends Controller
{
    public function dashboard(Request $request){
        return view('dashboard');
    }


    public function add_customer(Request $request){
     $message=null;
    if(isset($request->name)){
        if(@$_FILES['name']['name'] != '' && @$_FILES['name']['type'] == 'text/csv'){
          if (($open = fopen($_FILES['name']['tmp_name'], "r")) !== FALSE) {
            while (($data = fgetcsv($open, 100000, ",")) !== FALSE) {
              $datas[] = $data;
            }
            if(isset($datas) && count($datas) > 0){
              $cnt=0;
                foreach($datas as $data){
                  if($data[0] != 'firstName'){
                      $is_exist=Customer::where('firstName',trim($data[0]))->count();
                      if($is_exist == 0){
                        $add=new Customer();
                        $add->firstName=trim($data[0]);
                        $add->lastName=trim($data[1]);
                        $add->email=trim($data[2]);
                        $add->phoneNumber=trim($data[3]);
                     
                        $add->save();
                        $cnt++;
                      }
                  }
                }
                  $message="<font color=green>".$cnt." numbers of data Imported Successfully !</font>";
            }else{
              $message="<font color=red>Something went wrong ! Please check CSV file and try again.</font>";
            }
            fclose($open);

          }
        }else{
            $message="<font color=red>Something went wrong ! Please check CSV file and try again.</font>";
        }
    }
        return view('add_customer', compact('message'));
    }

    public function add_product(Request $request){
          $message=null;
    if(isset($request->name)){
        if(@$_FILES['name']['name'] != '' && @$_FILES['name']['type'] == 'text/csv'){
          if (($open = fopen($_FILES['name']['tmp_name'], "r")) !== FALSE) {
            while (($data = fgetcsv($open, 100000, ",")) !== FALSE) {
              $datas[] = $data;
            }
            if(isset($datas) && count($datas) > 0){
              $cnt=0;
                foreach($datas as $data){
                  if($data[0] != 'productname' || $data[1] != 'price'){
                      $is_exist=Product::where('productname',trim($data[0]))->count();
                      if($is_exist == 0){
                        $add=new Product();
                        $add->productname=trim($data[0]);
                        $add->price=$data[1];
                        
                        $add->save();
                        $cnt++;
                      }
                  }
                }
                  $message="<font color=green>".$cnt." numbers of data Imported Successfully !</font>";
            }else{
              $message="<font color=red>Something went wrong ! Please check CSV file and try again.</font>";
            }
            fclose($open);

          }
        }else{
            $message="<font color=red>Something went wrong ! Please check CSV file and try again.</font>";
        }
    }
        return view('add_product', compact('message'));
    }

    public function product_list(Request $request){
        $cart_count=Cart::where('product_id', '!=', '')->count();

        $datas=Product::orderby('productname')->get();
        return view('product_list', compact('datas', 'cart_count'));
    }

    public function add_to_cart($id, Request $request){
        $add=new Cart();
        $add->product_id=$id;
        $add->save();
        $message="<font color='green'>Prouct added to cart</font>";
        return redirect('/product_list');
    }

    public function cart(Request $request){
        $datas=DB::select("select carts.id,products.productname, products.price FROM
    products INNER JOIN carts ON products.id = carts.product_id");
        return view('cart', compact('datas'));
    }

    public function remove_cart($id, Request $request){
        $cart=Cart::find($id)->delete();
        return redirect('/cart');
    }

    
}
